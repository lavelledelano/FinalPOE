﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;



namespace FinalPOEAttempt1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // creating an instance for the class get_reminder [ global ]
        get_reminder reminder = new get_reminder();
        string hold_task = string.Empty;


        //global declaration for all instances and variables

        //List [ generic ]
        private List<QuizQuestion> quizData;

        //variables
        private int questionIndex = 0;
        private int currentScore = 0;

        //buttons
        private Button selectedChoice = null;
        private Button correctChoiceButton = null;
        public MainWindow()
        {
            InitializeComponent();
            //call the load quiz method 
            LoadQuizData();

            showQuiz();
        }

        public void greet()
        {
            //creating an instance for the media class
            MediaPlayer Audio_greet = new MediaPlayer();


            //get the path automatical
            string fullPath = AppDomain.CurrentDomain.BaseDirectory;

            //then replace the \\bin\\Debug\\net8.0-windows
            string replaced = fullPath.Replace("\\bin\\Debug\\net8.0-windows", "");

            //combine paths once done replacing
            string combine_path = System.IO.Path.Combine(replaced, "welcome.wav");

            //combine the url as uri
            Audio_greet.Open(new Uri(combine_path, UriKind.Relative));

            //play sound
            Audio_greet.Play();

        }

        private void Reminder(object sender, RoutedEventArgs e)
        {
            // hide other pages and set current one visible
            reminder_page.Visibility = Visibility.Visible;
            quiz_page.Visibility = Visibility.Hidden;
            activity_page.Visibility = Visibility.Hidden;
            questions.Visibility = Visibility.Hidden;
            ask_button.Visibility = Visibility.Hidden;

            // current
            showchats.Visibility = Visibility.Hidden;
        }

        private void set_reminder(object sender, RoutedEventArgs e)
        {

            // temporary variable to collect users input
            string temp_userTask = user_tasks.Text.ToString();

            // check if empty or not
            if (reminder.validate_input(temp_userTask) != "found")
            {
                MessageBox.Show(reminder.validate_input(temp_userTask));

            }

            // if all validated then check for the tasks


            if (temp_userTask.Contains("add task"))
            {

                // replace the found task on add task
                string get_description = temp_userTask.Replace("Add task", "");

                // add task message to the listview
                chat_append.Items.Add("task added with " + get_description + "\nWould you like to add a reminder? ");

                // then assign the task to the global variable
                hold_task = get_description;

                MessageBox.Show("task added with " + get_description);

            }
            else if (temp_userTask.Contains("remind"))
            {
                // check task holder
                if (hold_task != "")
                {
                    // get the day in users input
                    string hold_day = reminder.get_days(temp_userTask);

                    // check if today
                    if (hold_day == "today")
                    {
                        // get the message 
                        if (reminder.today_date(hold_day, hold_task) != "error. ")
                        {
                            // add to list
                            chat_append.Items.Add(reminder.today_date(hold_day, hold_task));
                        }
                        else
                        {
                            chat_append.Items.Add("Sorry, system chatbot failed to add task. ");
                        }
                    }
                    else
                    {
                        // get to calculate the date
                        if (reminder.get_remindDate(hold_task, hold_day) == "done")
                        {
                            chat_append.Items.Add("Great, I will remind you in " + hold_day + " days.");
                        }

                    }


                    // MessageBox.Show("Remind days are " + hold_day);
                }
                else
                {
                    // show error message
                    System.Console.Beep();
                    chat_append.Items.Add("No task was set to remind you. ");
                }
            }// end of else if statement
            if (temp_userTask.Contains("shows"))
            {
                chat_append.Items.Add("Your reminders are");
                chat_append.Items.Add(reminder.get_remind());
            }
        }




        private void quiz(object sender, RoutedEventArgs e)
        {
            // hide other pages and set current one visible
            reminder_page.Visibility = Visibility.Hidden;
            quiz_page.Visibility = Visibility.Visible;
            activity_page.Visibility = Visibility.Hidden;

            // current
            showchats.Visibility = Visibility.Hidden;
        }
            //method to show the  quiz on the buttons
        private void showQuiz()
        {

            //check if the user is not done playing
            if (questionIndex >= quizData.Count)
            {
                //show complete message
                MessageBox.Show("You already completed the game with " + currentScore + " score");
                //then reset the game
                currentScore = 0;
                currentScore = 0;
                questionIndex = 0;

                DisplayScore.Text = "";

                showQuiz();
                //stop the execute
                return;
            }

            //get the current index quiz
            correctChoiceButton = null;
            selectedChoice = null;

            //then get all the questions values
            var currentQuiz = quizData[questionIndex];

            //displays the question to the user
            DisplayedQuestion.Text = currentQuiz.Question;

            //add the choices to the buttons
            var shuffled = currentQuiz.Choices.OrderBy(_ => Guid.NewGuid()).ToList();

            //then add by index
            FirstChoiceButton.Content = shuffled[0];
            SecondChoiceButton.Content = shuffled[1];
            ThirdChoiceButton.Content = shuffled[2];

            //correct one
            FourthChoiceButton.Content = currentQuiz.CorrectChoice;

            clearStyle();
        }

        //method to rest the buttons
        private void clearStyle()
        {
            //use for each to reset
            foreach (Button choice in new[] { FirstChoiceButton, SecondChoiceButton, ThirdChoiceButton, FourthChoiceButton })
            {

                choice.Background = Brushes.LightGray;


            }


        }//end of the clear style method 


        //method to load the quiz data
        private void LoadQuizData()
        {
            //store info
            quizData = new List<QuizQuestion> {

                new QuizQuestion
                {
                    Question="Was ISEC nice on 12th June" ,
                    CorrectChoice ="it was not nice" ,
                    Choices = new List<string>
                    {
                        "was fair","was nice","was not bad"
                    }

                }   ,
                new QuizQuestion{

                    Question="Poe is due when ?" ,
                    CorrectChoice ="27th june" ,
                    Choices = new List<string>{
                    "27th may","27th Dec","27th Jan"
                    }

                }//end of second question, put , to add another one
             

            
            };


        }//end of the method load quiz data or info






        private void HandleAnswerSelection(object sender, RoutedEventArgs e)
        {

            //use sender object name to get the selected button
            selectedChoice = sender as Button;

            string chosen = selectedChoice.Content.ToString();

            //then check with correct on the current quiz
            string correct = quizData[questionIndex].CorrectChoice;

            //then check if correct or not by if statement
            if (chosen == correct)
            {
                //then set the button background color
                selectedChoice.Background = Brushes.Green;
                //assing to hold
                correctChoiceButton = selectedChoice;
            }
            else
            {
                //if incorrect
                selectedChoice.Background = Brushes.DarkRed;
                correctChoiceButton = selectedChoice;
            }



        }//end of handle answer selection event handler

        //event handler for the next button
        private void HandleNextQuestion(object sender, RoutedEventArgs e)
        {
            //check if the user selected one of the choices
            if (selectedChoice == null)
            {
                //then show error message
                MessageBox.Show("Choose one of the 4 choices");
            }
            else
            {
                //then add points , and only if correct
                string chosen = selectedChoice.Content.ToString();
                string correct = quizData[questionIndex].CorrectChoice;

                //check if correct 
                if (chosen == correct)
                {
                    //then add point
                    currentScore++;
                    //then show the score
                    DisplayScore.Text = "Score : " + currentScore;

                    //then move to the next index question
                    questionIndex++;
                    //show the question again for the next one
                    showQuiz();
                }
                else
                {
                    //move to the next question 
                    questionIndex++;
                    showQuiz();
                }

            }


        }//end of the handle next question event handler
    

        private void activity(object sender, RoutedEventArgs e)
        {
            // hide other pages and set current one visible
            reminder_page.Visibility = Visibility.Hidden;
            quiz_page.Visibility = Visibility.Hidden;
            activity_page.Visibility = Visibility.Visible;

            // current
            showchats.Visibility = Visibility.Hidden;
        }

        private void chats(object sender, RoutedEventArgs e)
        {
            // hide other pages and set current one visible
            reminder_page.Visibility = Visibility.Hidden;
            quiz_page.Visibility = Visibility.Hidden;
            activity_page.Visibility = Visibility.Hidden;


            // current
            showchats.Visibility = Visibility.Visible;
        }
        private void send_question(object sender, RoutedEventArgs e)
        {

            // collect users questions
            string collected_questions = questions.Text.ToString();

            // validate if not empty
            if (collected_questions != "")
            {
                // if question is asked

                showchats.Items.Add("You: " + collected_questions);



                showchats.Items.Add("Chatbot: Password needs to be 8 characters long. ");


                // then reset 
                showchats.Items.Add("Chatbot: Feel free to ask me more questions. ");

                // auto scroll
                showchats.ScrollIntoView(showchats.Items[showchats.Items.Count - 1]);
            }
            else
            {
                // then tell them to ask something
                showchats.Items.Add("Chatbot: Please ask something related to cyber. ");

            }
        }
        private void exits(object sender, RoutedEventArgs e)
        {
            // close the application
            System.Environment.Exit(0);
        }
    }
}